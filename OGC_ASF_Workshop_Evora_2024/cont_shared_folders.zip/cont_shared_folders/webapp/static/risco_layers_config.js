var RISCOJS_LAYERS_CFG = {
	"lorder": ["EV","edificios", "AL", "arqueologia"], 
	"basemaps": [
		"ortos_2015",
		"ortos_2018"
	],
	"relations": [
	],
	"layers": {
		"grat": {
			"type": "graticule",
			"strokeStyle": "white",
			"lineWidth": 1
		},		
		"grat_crosses": {
			"type": "ptgrid",
			"marker": "vertcross",
			"markersize": 2,
			"strokeStyle": "white",
			"lineWidth": 2,
			"maxscale": 10000
		},	
		"ortos_2018": {
			"label":"Orthoimages 2018",
			"type": "wms",
			"url": "http://localhost:9200/wms/ortos2018",
			"layernames": "Ortos2018-RGB",
			"envsplit": false,
			"filter": "grayscale",		
			"imageformat": "image/jpeg"
		},
		"ortos_2015": {
			"label":"Orthoimages 2015",
			"type": "wms",
			"url": "http://localhost:9200/wms/ortos2015",
			"layernames": "Ortos2015-RGB",
			"envsplit": false,
			"filter": "grayscale",		
			"imageformat": "image/jpeg"
		},		
		"EV": {
			"label":"eixo_de_via",
			"type": "riscofeats",
			"geomtype": "line",
			//"label": "Eixos de via",
			"mouseinteraction": false,
			"url": "http://localhost:8020",
			"lineDash": [8,2], 
			"lineWidth": 4,
			"strokeStyle": "#46b5d0",
			"labelfield": "name",
			"labelplacement": "along",
			"labelFontSizePX": 18,
			"labelFontFace": "OpenSans-CondensedRegular",

			"envsplit": false,
			"fillStyle": "none",
			"maptipfields": {
				"add": [
					"osm_type", "surface", "ref", "oneway", "name", "maxspeed", "lit", "lanes", "int_ref", "highway"
				]
			},
			"msgsdict": {
				"deflang": "en",
				"pt": {
					"eixo_de_via": "eixos de via"
				},
				"en": {
					"eixo_de_via": "centerlines"
				}				
			}
		},
		"AL": {
			"label": "AL",
			"type": "riscofeats",
			"geomtype": "point",
			"url": "http://localhost:8020",
			"layervisible": false,
			"mouseinteraction": true,
			"marker": "circle",
			"markersize": 6,
			"strokeStyle": "white",
			"fillStyle": "orange",
			"lineWidth": 1,
			"maxscale": 10000,
			/*"varstyles": [
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 0) },
					"key": "undef_e",
					"fillStyle": "rgba(100, 100, 250, 0.9)"
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 1) },
					"key": "bom_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.b
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 2) },
					"key": "dob_e",
					"fillStyle": "rgb(255, 196, 0)"
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 3) },
					"key": "ac_e",
					"fillStyle": "rgb(240, 141, 12)"
					//"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.ora_green.c,
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 4) },
					"key": "grf_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.d
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 5) },
					"key": "ferr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.c
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 6) },
					"key": "outr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.c,
				}
			], */

			"labelfield": "nrutentes",
			"labelFontSizePX": 16,
			"labelFontFace": "monospace",
			"labelFillStyle": "black",
			"labelPositionShift": [0,2],

			"msgsdict": {
				"deflang": "pt",
				"pt": {
					"AL": "alojamento local",
					"nrutentes": "núm. utentes"

				},
				"en": {
					"AL": "local accommodation",
					"nrutentes": "num. of guests",
					"denominacao": "name",
					"modalidade": "type",
					"endereco": "address",
					"codigopostal": "postal code"
				}
			},
			"maptipfields": {
				"add": [
					"denominacao","modalidade", "nrutentes"
				]
			},
			"infocfg": {
				"fields": {
					"add": [
						"denominacao","modalidade", "endereco", "codigopostal", "nrutentes"
					],
					"formats": {	
					},
					"transforms": [
					]
				}
			}
		},
		"arqueologia": {
			"label": "arqueologia",
			"type": "riscofeats",
			"geomtype": "point",
			"url": "http://localhost:8020",
			"layervisible": true,
			"mouseinteraction": true,
			"marker": "circle",
			"markersize": 6,
			"strokeStyle": "white",
			"fillStyle": "green",
			"lineWidth": 1,
			"maxscale": 10000,
			/*"varstyles": [
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 0) },
					"key": "undef_e",
					"fillStyle": "rgba(100, 100, 250, 0.9)"
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 1) },
					"key": "bom_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.b
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 2) },
					"key": "dob_e",
					"fillStyle": "rgb(255, 196, 0)"
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 3) },
					"key": "ac_e",
					"fillStyle": "rgb(240, 141, 12)"
					//"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.ora_green.c,
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 4) },
					"key": "grf_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.d
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 5) },
					"key": "ferr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.c
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 6) },
					"key": "outr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.c,
				}
			], */
			"layereditable": {
				"gisid": "globalid"
			},	
			"msgsdict": {
				"deflang": "pt",
				"pt": {
					"periodos": "períodos",
					"designacao": "designação"
				},
				"en": {
					"arqueologia": "archeaology",
					"designacao": "designation",
					"periodos": "periods",
					"tipo": "type"
				}
			},
			"maptipfields": {
				"add": [
					"designacao","tipo"
				]
			},
			"infocfg": {
				"fields": {
					"add": [
						"designacao","tipo", "periodos", "url"
					],
					"formats": {	
						"url": {
							"type": "URL",
							"urlbuild": (value) => value
						},						
					},
					"transforms": [
					]
				}
			}
		},
		"edificios": {
			"label": "edificios",
			"type": "riscofeats",
			"geomtype": "poly",
			"url": "http://localhost:8020",
			"layervisible": true,
			"mouseinteraction": true,
			"strokeStyle": "white",
			"fillStyle": "rgba(120, 120, 120, 0.5)",
			"lineWidth": 1,
			"maxscale": 10000,
			/*"varstyles": [
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 0) },
					"key": "undef_e",
					"fillStyle": "rgba(100, 100, 250, 0.9)"
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 1) },
					"key": "bom_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.b
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 2) },
					"key": "dob_e",
					"fillStyle": "rgb(255, 196, 0)"
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 3) },
					"key": "ac_e",
					"fillStyle": "rgb(240, 141, 12)"
					//"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.ora_green.c,
				},				
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 4) },
					"key": "grf_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.d
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 5) },
					"key": "ferr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.mag_ora.c
				},
				{
					"func": (p_utils, scl, attrs) => { return (attrs.cod_estado_conservacao == 6) },
					"key": "outr_e",
					"fillStyle": RISCOJS_COLORRAMPS.RAMPS4X4.green_blue.c,
				}
			], */
			"msgsdict": {
				"deflang": "pt",
				"pt": {
					"edificios": "edifícios",
					"periodos": "períodos",
					"designacao": "designação"
				},
				"en": {
					"edificios": "buildings",
					"designacao": "designation",
					"periodos": "periods",
					"tipo": "type"
				}
			},
			"maptipfields": {
				"add": [
					"osm_type", "leisure", "landuse", "tourism", "website", "historic", "wikipedia", 
					"site_status", "amenity", "name", "heritage:website:sipa", "heritage:website", "heritage:since", "building", "alt_name"
				]
			},
			"infocfg": {
				"fields": {
					"add": [
						"designacao","tipo", "periodos", "url"
					],
					"formats": {	
						"url": {
							"type": "URL",
							"urlbuild": (value) => value
						},						
					},
					"transforms": [
					]
				}
			}
		}				

	}

}
