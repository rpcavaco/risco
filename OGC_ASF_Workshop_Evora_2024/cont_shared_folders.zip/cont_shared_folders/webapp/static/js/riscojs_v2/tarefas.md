
# Tarefas pendentes SINVERTDEV

## Query NIP/NIPA 

- OK - Alteração método web doget e respetiva funcionalidade de base de dados (ASTATS)
- incluir painel adicional

## Adição painel adicional

- adição layer

## Dashboarding

## Segunda foto 



# BUGS

- BUG0001 - Formulário INFO só uma foto nas segundas páginas não dimensiona corretamente em altura (está a adaptar à largura e não à altura disponível, que é menor)


