
// Portuguese items for now

export var WKID_List = {
	4326: 4326,
	3763: 3763,
	102100: 3857,
	102161: 27493,
	102163: 2963, // LX Bessel Bonne
	102164: 20790, // Lisboa Hayford Gauss IGeoE
	102165: 20791
}